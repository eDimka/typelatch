# Usage

Start with a workspace question, inspect the relevant source or exact dependency APIs, then check their use in a local TypeScript project. The CLI and MCP server share the same implementation.

## Install and connect

Requires Node.js 22.12 or newer, npm, Bash, and the Codex or Claude Code CLI on `PATH`. Run this from any directory:

```sh
npx typelatch@0.4.0 setup
```

Choose your client, keep or change the server name, then confirm registration. Setup pins the exact Typelatch version being run and configures npm as the server launcher. It does not require a clone, global installation, or a project dependency. The client can launch it after npm clears its temporary package cache. Restart your client in the project and ask: "Use workspace_search to explain how this project is organized."

Running setup again with a newer release prepares a registration for that version. Codex can replace the named entry; Claude Code may require you to remove the old entry first or choose another name.

To prepare dependency indexes without installing globally, run `npx typelatch@0.4.0 sync` in your project. The SQLite dependency uses a native binary. If no suitable binary is available, npm installation requires a working C++ build toolchain. Initial installation and an uncached server launch need npm access.

### Source checkout and manual registration

From a source checkout, run `npm run setup:mcp` for interactive registration with Codex or Claude Code. You can also run `bash scripts/setup-mcp.sh` directly. Choose the current checkout, an installed `typelatch-mcp`, or an exact npm package version, then review and confirm the command. Registration uses your client user configuration.

The checkout option runs `npm ci` if `node_modules` is missing and builds before registration. It records absolute Node and server paths, so keep the checkout in place. The installed option records the executable found on `PATH`. The npm option looks up the current published version and checks the selected exact version before registration. It needs network access and may download the package when the server first starts. Published versions can have fewer tools than the current source. Registration does not itself verify server health.

Requires Node.js 22.12 or newer and npm. The SQLite dependency uses a native binary. If your platform has no suitable binary, installation requires a working C++ build toolchain.

```sh
npm install --global typelatch@0.4.0
typelatch --help
typelatch add kysely@0.28.19
```

`add` downloads an npm artifact, verifies its registry integrity, and indexes its TypeScript APIs without running package lifecycle scripts. It does not add a dependency to your workspace. Search uses that local index after preparation, including when offline.

**Codex**

```sh
codex mcp add typelatch -- typelatch-mcp
```

The corresponding entry in `~/.codex/config.toml` is:

```toml
[mcp_servers.typelatch]
command = "typelatch-mcp"
```

**Claude Code**

```sh
claude mcp add --transport stdio --scope user typelatch -- typelatch-mcp
```

For a client that accepts an MCP JSON configuration:

```json
{
  "mcpServers": {
    "typelatch": {
      "command": "typelatch-mcp"
    }
  }
}
```

Start a new client session after registration or upgrading. Typelatch exposes the [seven tools](#mcp-tool-reference) over standard input and output, including `workspace_search`. If the client cannot find `typelatch-mcp`, check the executable path in the environment that launches the client or configure its absolute path.

<details>
<summary>Use npm without a global installation</summary>

Prepare the same local index:

```sh
npx --yes --package=typelatch@0.4.0 typelatch add kysely@0.28.19
```

Register either client with npm as the launcher:

```sh
codex mcp add typelatch -- npx --yes --package=typelatch@0.4.0 typelatch-mcp
claude mcp add --transport stdio --scope user typelatch -- npx --yes --package=typelatch@0.4.0 typelatch-mcp
```

The package name is `typelatch`. Its server executable is `typelatch-mcp`. Do not use `npx typelatch-mcp`, which asks npm for a different package. The npm launcher may need network access before it can start the server. Use the same `TYPELATCH_HOME` for index preparation and the server if you override the default.

</details>

## Try the SQLite task

The [recorded Codex session](showcase/codex-session.md) demonstrates finding and fixing a broken implementation with workspace search, installed API evidence and unchanged assertions. Its animation summarizes one prompted session on an authored exercise; it does not measure improvement against another agent run. That retained session used `kysely@0.28.8`; the maintained example and commands below now use `kysely@0.28.19`.

The [SQLite fixture](../examples/sqlite) imports a batch of contacts through Kysely and `better-sqlite3`. A duplicate name must reject the batch and leave no partial inserts. It uses an in memory database, not your application's data or Typelatch's index.

From a trusted source checkout, install the fixture's pinned dependencies and prepare its API index:

```sh
npm ci --prefix examples/sqlite
typelatch add kysely@0.28.19
```

Open Codex or Claude Code at the repository root with Typelatch connected. This prompt gives the agent a concrete question and a narrow execution authorization:

```text
In examples/sqlite, use Typelatch to answer this question:
How can I import a batch of contacts into SQLite atomically, roll back
every new row if a UNIQUE name constraint fails, and safely store a
name containing a quote?

Search the local kysely@0.28.19 index with library_search. If the first
results do not explain the callback transaction, refine the question
to "TransactionBuilder execute". Inspect the returned transaction API
with library_symbol. Cite the exact
package version, symbol, and source location. Read batch.ts and
batch.test.ts. Explain whether importContacts meets the requirement.
If a change is needed, edit only examples/sqlite/batch.ts and preserve
the assertions.

Use workspace_context with absolute config and file paths to resolve
the API in this fixture. Then use workspace_validate with the absolute
path to examples/sqlite/tsconfig.json and exactly this testCommand:
["npm", "test"]

I authorize that assertion command only inside examples/sqlite.
You may inspect fixture files, but do not run other test or application
commands, install packages, or access external databases.
Report retrieval, resolution, compilation, and assertion execution
separately. Keep unknown and not-run evidence visible.
```

The fixture already contains an implementation, so this prompt reviews and validates it rather than claiming to be an unseen coding benchmark. The separate historical [recording](showcase/recording.json) preserves actual MCP requests and results for `kysely@0.28.8` from an SDK client talking to published `typelatch@0.1.1` over stdio. Its original fixture is retained as [text and hashes](showcase/recorded-fixture.json). The question and implementation were authored by Jcode. It is not a recording of Codex or Claude Code. [Capture provenance and reproduction](showcase/README.md) describe the run.

A client can use its normal file tools for edits. Typelatch does not edit source files.

## Library discovery

An explicit version makes an index request reproducible. Without one, `add` first checks the project lockfile and otherwise resolves through npm. Search without a version uses the newest installed index, not necessarily the workspace version.

```sh
typelatch add kysely@0.28.19
typelatch query kysely@0.28.19 "TransactionBuilder execute" --json --limit 5
typelatch sync
```

`sync` indexes direct locked dependencies, including development and optional dependencies. Supply package names to restrict it, for example `typelatch sync kysely`. Packages need TypeScript declarations or usable TypeScript sources. Indexing a JavaScript package does not automatically fetch its separate `@types` package. Packages without usable TypeScript evidence are reported as `unsupported`, and synchronization continues for the remaining dependencies. JSON output can report `success: true` with `complete: false`; inspect each result and its reason. Download, integrity and parse failures still stop synchronization with an error.

| Package manager | Lockfile | Supported schema |
| :--- | :--- | :--- |
| npm | `package-lock.json`, `npm-shrinkwrap.json` | 1 to 4; ordinary registry entries only |
| pnpm | `pnpm-lock.yaml` | 5 including 5.3 and 5.4, 6, 9 |
| Yarn | `yarn.lock` | Classic and modern Yarn |
| Bun | `bun.lock` | 0, 1, 2 |
| Bun legacy binary | `bun.lockb` | Binary formats 2 and 3, through an installed Bun executable on `PATH` |
| Deno | `deno.lock` | 2, 3, 4, 5; exact npm entries only |

Workspace packages can use a lockfile in a parent directory. Aliases retain the actual registry package name. Lockfile discovery works in JavaScript projects without a `tsconfig.json`. This does not change the TypeScript evidence required for package API indexing.

If several package managers have lockfiles, set `packageManager` in `package.json` to choose one. npm shrinkwrap takes precedence for legacy npm; an explicit `npm@12` or newer selects `package-lock.json` because [npm 12 no longer reads shrinkwrap](https://docs.npmjs.com/cli/v12/configuring-npm/package-lock-json/#npm-shrinkwrapjson). Bun text takes precedence over Bun binary. Binary reading uses [Bun's lockfile printer](https://bun.sh/guides/install/yarnlock) on a temporary copy of the observed bytes. It does not install dependencies or run lifecycle scripts.

pnpm and Bun catalogs use the exact resolved entries in the lockfile. Binary Bun catalog aliases also use catalog declarations from the root `package.json` to recover the package name omitted by the printer. Yarn catalogs use the root `.yarnrc.yml` catalog declarations to select the matching locked descriptor. Missing catalog entries or descriptors remain unresolved; Typelatch never chooses a version from a catalog range. Unrelated Yarn configuration fields are not retained as catalog evidence.

Deno projects can declare npm imports in `deno.json` or `deno.jsonc`, including aliases and import subpaths. Declared Deno workspace members, inherited root imports and saved project selections are supported. Package API indexing covers exact npm entries with recorded integrity, using the [Deno lockfile formats](https://github.com/denoland/deno/tree/main/libs/lockfile). JSR packages, remote modules, npm tarball overrides, external import maps, scoped import maps, links, vendored resolution, disabled locking and custom lockfile paths produce explicit limitations. Typelatch does not run the Deno compiler or index JSR package APIs. Schema 1 contained remote module hashes and is not supported for npm API indexing.

An explicit npm or Yarn Classic artifact URL must identify the canonical package and version tarball on `registry.npmjs.org` or `registry.yarnpkg.com`, or carry an integrity value that must match registry metadata when downloaded. Custom URLs without that evidence are rejected. Legacy canonical URLs with a SHA1 fragment retain registry identity; that fragment is not promoted to a separately verified integrity field.

Without a saved scope, `sync` defaults to the package in the current directory. Select projects explicitly or expand the workspace declarations:

```sh
typelatch sync --workspaces
typelatch sync --project apps/web --project services/api
typelatch sync kysely --project apps/web
typelatch sync --workspaces --dry-run --json
typelatch sync --project apps/web --lockfile pnpm-lock.yaml
```

`--workspaces` includes the root and declared member packages from `package.json`, `pnpm-workspace.yaml`, `deno.json` or `deno.jsonc`, including declared exclusions. It does not automatically include unrelated examples or fixtures. Repeated `--project` flags replace the default selection and cannot be combined with `--workspaces`. Project paths and the optional `--lockfile` path are relative to the current directory. A lockfile override applies to one selected project and must be in that project's directory or an ancestor.

### Keep a monorepo subset

Save the projects you work on, then add more when needed. Run these commands from the repository root:

```sh
typelatch scope add apps/web packages/ui
typelatch sync --dry-run --json
typelatch sync
typelatch search "Where are requests validated?"

typelatch scope add services/api
typelatch sync
typelatch scope list
typelatch scope remove apps/web
```

`scope add` preserves the existing selection and ignores duplicates. `scope set <project ...>` replaces it. Each path must name a directory with a `package.json`. Paths are relative to the current directory and saved relative to the repository or workspace root in `.typelatch/scope.json`. Commands in descendant directories find the nearest saved scope. Keep `.typelatch/` ignored for a personal selection.

The saved scope applies to plain `sync`, CLI search, and MCP `workspace_search`. Search indexes the selected source subtrees and discovers only the selected projects' direct dependencies. Include local workspace packages explicitly when you want their source searched. Ancestor lockfiles and manifests can supply dependency identities without adding ancestor source or dependencies. Yarn Classic may also read declared member manifests to identify local workspace dependencies.

Scope commands save the selection without downloading or indexing. Source changes take effect on the next search, including in an already running MCP server. Adding projects reuses unchanged source entries and existing package indexes. Removing projects removes their source from the workspace index on the next search. Shared package indexes remain available for other projects and explicit library queries.

`scope list --json` shows the active configuration. Removing the last project leaves an explicit empty selection. `scope clear` removes the nearest saved scope, restoring the defaults unless an ancestor has another saved scope. Malformed configurations and missing selected projects produce errors instead of falling back to the whole repository.

Explicit `sync --project` or `sync --workspaces` overrides the saved selection for that invocation without changing it. Search always intersects the saved source selection with its requested `workspaceRoot`, so a narrower search never expands to sibling projects. `coverage.savedScope` records the selection and its direct dependency policy. Completeness refers to that subset. The saved scope controls discovery and sync; explicit library queries, workspace context and validation keep their own requested targets.

### Sync plans and identity

Each project uses its nearest applicable lockfile. Independent nested projects can use different package managers. The complete plan is checked before downloads begin. Identical package artifacts are indexed once; different versions are retained. Conflicting integrity values for the same package and version stop sync because one cache entry cannot represent both artifacts.

`--dry-run` reads local files and cache metadata without downloading packages or building indexes. Its output shows selected projects, lockfile paths, exact versions, cache status, skipped local dependencies and problems. Add `--json` for a structured plan. A plan with errors returns a nonzero exit code. Normal `--json` execution also returns per package results. Existing indexes are reused only when their metadata matches the requested identity; `--force` rebuilds them.

Malformed files, unknown schemas and unresolved direct registry identities produce errors. Local workspace, file and link declarations are not downloaded by `sync` as registry packages. Git, patched and repaired package entries are not represented as unchanged registry artifacts. A binary `bun.lockb` containing patch records requires conversion to text because Bun's Yarn printer does not retain those records. Without Bun on `PATH`, convert the binary lockfile with `bun install --save-text-lockfile --frozen-lockfile --lockfile-only` before using Typelatch.

The equivalent `library_search` request is:

```json
{
  "package": "kysely",
  "version": "0.28.19",
  "question": "TransactionBuilder execute",
  "limit": 5
}
```

This uses the same refined question as the historical recording, with the maintained fixture version. The historical requests retain their original `kysely@0.28.8` identity. That capture keeps the initial and refined searches rather than presenting the refined result as the first attempt.

For this result, the exact `library_symbol` request is:

```json
{
  "package": "kysely",
  "version": "0.28.19",
  "symbol": "esm/kysely.TransactionBuilder"
}
```

The CLI equivalent is:

```sh
typelatch symbol kysely@0.28.19 esm/kysely.TransactionBuilder --json
```

For other packages, use the exact returned `symbol` with the same `package` and `version`. Lookup is case sensitive. A qualified symbol must match that exact module and declaration; a missing qualified symbol never falls back to another module. Bare names can match several declarations. The `lookup` object reports `exact`, `ambiguous` or `not-found`, plus `totalMatches` and `omitted` counts, even when the returned list hides some candidates. Responses retain package identity, source locations, signatures, documentation, relationships, and retrieval signals. Finding a candidate does not establish that it resolves or compiles in your project.

When a library question names at least two distinct qualified APIs, search returns their exact matches in first mention order before filling remaining slots with lexical candidates. For example, `Schema.Trim Schema.filter Schema.NonEmptyArray Schema.Struct` requests four separate identities. The optional `requestedSymbols` list reports each recognized name as `exact` when returned, `not-found` when absent from that exact package index, or `omitted` when present but excluded by the result limit. An alias or differently cased name is not inferred to mean another declaration. Recognition checks the first 64 distinct names and reports any additional distinct names in `requestedSymbolsTruncated`.

This recognition covers complete ASCII dotted identifiers in prose, including quoted names. Tokens containing URLs, email addresses or filesystem paths, common filename extensions and prose abbreviations are excluded. Use `library_symbol` for paths, filename spellings, Unicode or other identities outside that recognition. Single name and ordinary questions retain their existing discovery behavior. These metadata describe the local index, rather than compiler resolution or complete workspace absence.

If the requested exact package index is missing, both library tools return an error naming that package and version with its `typelatch add name@version` recovery command. They do not download an index or substitute another installed version. Omitting `version` keeps the existing newest installed index selection; pass an exact version when following evidence from a project.

Both tools validate managed index metadata before returning evidence. Stored package and version must match the requested identity, and stored artifact integrity must be nonblank. An identity mismatch or incomplete metadata returns `Brain metadata does not match name@version. Rebuild: typelatch add name@version`. Valid older index formats remain readable without rebuilding. This check protects the cache label; it does not revalidate the registry archive or establish that installed package files match it.

New indexes retain declared generics, parameters and return annotations for direct callable variable initializers. The `…` marker means the implementation is omitted. An absent return annotation remains absent; package discovery does not infer it. Existing indexes remain readable. Run `typelatch add name@version` again to rebuild an older index with the corrected callable evidence.

## Workspace search

For a complete task, follow the [agent workflow showcase](showcase/agent-workflow.md). It starts from a broken contact import, discovers source without naming a package, inspects an exact dependency API, and captures the same assertions failing before and passing after the edit. A preparation command gives your own agent an isolated exercise; a separate replay records actual MCP and CLI output.

Install or upgrade with `npm install --global typelatch@0.4.0`, then restart the MCP client so it discovers the new tool.

Use `workspace_search` when the relevant file or dependency is unknown:

```json
{
  "workspaceRoot": "/absolute/path/to/repo",
  "question": "Where do we validate incoming requests?",
  "limit": 8
}
```

The CLI uses the current directory by default:

```sh
typelatch search "Where do we validate incoming requests?" --json
typelatch search "retry failed requests" --root /absolute/path/to/repo --json
typelatch search "validateRequest" --scope workspace --file src/server.ts --json
typelatch search "retry with exponential delay" --scope dependencies --json
typelatch search "retry failed requests" --compact --json
```

`scope` is `all` by default, or `workspace` or `dependencies`. `file` is an optional path within the root that favors nearby workspace results. It does not limit the search or establish compiler resolution. `limit` is 1 through 20 and defaults to 8. MCP accepts `timeoutMs`, defaulting to 60000. Cancellation fails the request rather than returning an apparently complete result.

For workspace and combined discovery, an eligible exact file hint selected by Git is considered before the existing inventory limits. Saved source scope, ignored files, generated directories, physical source and file size rules still apply. Prioritizing a file can displace other files at a limit, so partial coverage stays visible. The question must still match and the bounded candidate shortlist can still omit an admitted file. `coverage.fileHint` records the relative path, `admission`, `priorityApplied`, the current searchable source hash when admitted, and a reason. Admission describes the inventory used for this request, not retrieval or compiler evidence. Filesystem fallback can admit a hint normally while reporting `priorityApplied: false`. Dependency only search keeps its existing inventory ordering and output.

Use `detail: "compact"` in MCP or `--compact` in the CLI for smaller discovery previews. The default is `full`. Compact results retain the same shortlist, ranking, source positions, coverage and evidence checks. Each snippet contains at most 360 Unicode characters, with `preview.omittedCharacters` recording any omitted portion of the original excerpt. Null package fields and duplicate signatures are omitted. Dependency hits include exact `inspect` arguments for `library_symbol`. Read the source or inspect the symbol before changing code; a preview is not the complete declaration. Compact mode is an output projection and does not change what gets indexed or searched.

Use `detail: "source"` or CLI `--source` when preparing an edit. It adds `sourceContext` to the compact results. Selected workspace files appear once, followed by available direct relative import candidates. Text comes from the same inventory used for search freshness. Each file includes its full content SHA256, returned line range, text byte count and explicit omitted bytes. A complete file has `complete: true`. Larger files return a bounded region near the first selected hit. `startLine` and `startColumn` begin at one; columns count UTF16 code units. The CLI prints both so an excerpt beginning inside a long line remains locatable.

Source text is limited to 24 KiB in total, 8 KiB per file and 12 files. These limits exclude JSON metadata. `filesOmitted` counts candidates excluded by the limits. `unavailableImports` includes ambiguous matches, also counted in `ambiguousImports`. Import expansion uses only already selected inventory files, respects ignores and symlink exclusions, and follows one level. It does not evaluate compiler settings, package aliases or conditional exports. `resolution: "not-run"` remains explicit. Dependency results retain exact identity and inspection arguments without expanding dependency implementation files. Read omitted source before editing it.

Source search includes internal declarations, implementation text, tests, documentation, and configuration. TypeScript and JavaScript declarations receive symbol names and UTF16 positions when the bundled parser recognizes them. Other UTF8 text is searched as text. No project compiler or application code executes during search.

In Git workspaces, the inventory includes tracked and unignored files, including uncommitted edits. Generated and dependency directories, source symlinks, binary files, environment files, and common archive or media formats are excluded. Lockfiles supply dependency identities and are excluded from content retrieval. Outside Git, filesystem traversal remains available and reports that Git ignore rules were not applied. The response names the selection policy and samples exclusions. Linked source outside the root is outside the search scope.

Large repositories can exceed the 20,000 enumerated entry or 64 MiB inventory limits. Files normally have a 1 MB limit, and indexing also limits chunks per file. Inspect `coverage.complete`, `coverage.issues` and their omission counts. A returned hit can coexist with partial coverage. Refining the question cannot recover files that were excluded from the inventory.

When the relevant source subtree is known, select it as the search root:

```sh
typelatch search "streamed file reads cancellation" --root /absolute/path/to/repo/src/platform --scope workspace --json
```

For project selections across a monorepo, use the [saved scope](#keep-a-monorepo-subset) commands. A subtree root limits discovery to that tree; choose the actual owning config separately before compiler context or validation.

Search discovers nested package manifests, TypeScript configs, installed dependencies and nested transitive installations. It uses each installed manifest's name and exact version, including aliases and multiple versions, rather than the newest global index. Supported npm, pnpm, Yarn and Bun text lockfiles also provide exact candidates when packages are not installed. These results are labeled `identity: "lockfile"` and `installed: false`. A lockfile candidate is not proof of workspace resolution. Unsupported formats and resolutions are reported as coverage gaps; available installed manifests can still supply identities. For lock entries without an installation path, dependency roots point to the lockfile. Modern Yarn checksums describe Yarn archives and are not treated as npm artifact integrity. Unidentified declared dependencies are reported.

Search uses existing package indexes and does not download or build missing ones. Run `typelatch sync --workspaces` for declared workspace packages, or select projects with repeated `--project` flags, to prepare their direct locked dependencies. Missing entries in `coverage.dependencies` include exact `typelatch add name@version` commands, including for transitive packages. A JavaScript package without usable TypeScript declarations may still be unindexable. Do not substitute another version. Registry metadata and any available lockfile integrity must match; installed artifact equivalence remains unknown.

Each source hit includes an absolute `source`, `line`, `endLine`, compact `snippet`, owning `projectRoot`, and optional `symbol` and `position`. A dependency hit instead identifies its package, exact version, registry integrity, artifact relative source path, and known dependency roots. Inspect it with `library_symbol` using that identity. `coverage.configs` lists discovered configs; the agent must select one that owns the relevant file before using `workspace_context`.

When a solution delegates file selection to several owning configs, context reports ambiguity and names the configs; repeat the request with one explicit owning config.

The agent workflow is:

1. Search with a concrete question. Check `coverage` before interpreting the results.
2. Read relevant source locations. For dependency hits, inspect the exact returned symbol with `library_symbol`.
3. Use `workspace_context` to resolve an actual use in the appropriate project.
4. Make the change with normal file tools.
5. Use `workspace_validate` for the affected leaf projects and explicitly authorized assertion commands. Keep retrieval, resolution, compilation, and execution evidence separate.

Suggested agent instruction:

```text
Use workspace_search when the relevant file or package is unknown.
Supply the repository's absolute root and a focused question. Inspect
coverage gaps and returned source locations. Use library_symbol with
the returned package and exact version for dependency detail, and
workspace_context for compiler resolution of an actual workspace use.
After editing, use workspace_validate for the affected projects and
authorized assertions. Report missing evidence separately.
```

The result `status` is `ok` when candidates were found with complete declared inventory coverage, `empty` when no candidates were found with that coverage, and `partial` when inventories, indexes, or file indexing have gaps. `coverage.complete` refers to the declared inventory policy, not exhaustive retrieval, semantic understanding, or an atomic filesystem snapshot. The evidence checks explicitly leave resolution, compilation, and tests as `not-run`, and stability and installed artifact matching as `unknown`.

Retrieval is lexical and uses a shared content score across source and dependency candidates, with a bounded shortlist and overlap suppression. It does not use embeddings. Current limits are 20000 inventoried paths, 1 MB per source file, 64 MiB of workspace text, 2000 dependency installations, 500 chunks per file, 400 workspace candidates, 20 candidates per dependency, and 20 returned hits. A saved scope is applied before source enumeration and its limits. Scoped dependency discovery allows 2000 direct declarations and lockfiles up to 16 MiB. Coverage reports inventory and indexing limits. Retrieval limits remain explicit even when inventory coverage is complete. Dependency coverage details prioritize gaps and show up to 40 entries with omitted counts; large project and config inventories are also summarized. An empty shortlist never proves that a symbol or behavior is absent.

The SQLite cache lives under `~/.typelatch/workspaces`, or the selected `TYPELATCH_HOME`. It stores search postings, source paths and excerpt positions. Excerpts are reconstructed from the contents read for the current request. The postings still reveal source terms, so treat the cache as workspace data. Every search reads file contents and checks hashes, so same size edits with preserved timestamps, additions, removals, and changed ignore rules refresh the index. Unchanged files reuse cached chunk positions. `TYPELATCH_USAGE=off` controls query history, not this cache. Workspace searches currently do not create `library_feedback` query IDs or contribute to `library_stats`.

## Workspace context

Save this request as `context.json`, replacing the paths with your absolute fixture paths:

```json
{
  "config": "/path/to/typelatch/examples/sqlite/tsconfig.json",
  "file": "/path/to/typelatch/examples/sqlite/batch.ts",
  "importSpecifier": "kysely",
  "symbol": "Kysely",
  "expectedVersion": "0.28.19"
}
```

Pass those fields to `workspace_context`, or use the CLI:

```sh
typelatch workspace context.json
```

For a known installed export, supply `importSpecifier` and its exact `symbol` path, such as `Schema.Struct`. Omit `question` and `position` to use the `installed-api` route without preparing a package index. Context uses the project's installed TypeScript compiler and returns resolved dependency identity and API evidence. It does not compile the project or run tests.

`api.type` and `api.signatures` are compiler formatted and can include inference. Signatures use the callable value when a declaration also defines an interface. `api.evidence.declarations.headers` separately returns normalized declared syntax, source positions and hashes of the compiler source text. Headers omit implementation bodies, class and namespace members, and unsupported variable initializers. They preserve declared annotations rather than inventing return types. Each header exposes its elisions and `complete`, `truncated` or `unsupported` status. Here `complete` means complete under this elision policy. An unsupported header has a reason and no header text. Older project compilers can still return resolved types and signatures; when their modifier or declaration factory APIs cannot support normalized headers, that projection reports `unsupported` with a reason.

`api.evidence` records total, returned and omitted counts. Text counts use UTF16 code units. Existing limits are 16000 for the type, 12000 for documentation, ten signatures of 8000 each, and ten declaration spans. Additional evidence contains up to ten headers of 8000 each and ten compiler JSDoc tags, with 256 units per name and 4000 per tag text. Documentation and tags are compiler views, not full package documentation or an API graph. These richer responses have a payload cost; preparing no index does not imply lower query memory or latency.

Add `question` to request separate discovery from an existing matching local index. Add `position` to request hover, definitions and references. The evidence extension is attached only to the explicitly selected `api`, so discovery candidates do not repeat the declaration headers and tags.

`cursorEvidence` records the selected compiler config, cursor position and counts for definitions and references. Each collection reports its compiler total, returned and omitted entries, limit, and `complete`, `truncated` or `not-run` status. Definitions return at most 20 entries and references at most 50. A request without a cursor has null totals and omitted counts. A requested cursor with no compiler results has zero counts. Complete means no entries were omitted from that compiler result in the selected project. These counts do not establish complete repository impact or validate usages.

`position` is a UTF16 offset starting at zero. Use it to inspect an actual expression in the file. `overlays` accepts unsaved `{ "file": "...", "text": "..." }` entries. Absolute paths avoid ambiguity when a client starts outside the project.

`expectedVersion` checks the package containing the resolved declaration. When declarations come from a separate `@types` package, that identity can differ from the runtime package. A matching version is not proof that installed files equal the registry artifact.

## Validation

Save this request as `validation.json`, replacing the config path:

```json
{
  "config": "/path/to/typelatch/examples/sqlite/tsconfig.json",
  "workspaceRoot": "/path/to/typelatch/examples/sqlite",
  "testCommand": ["npm", "test"],
  "timeoutMs": 60000,
  "record": true
}
```

Pass those fields to `workspace_validate`, or use the CLI:

```sh
typelatch validate validation.json
```

The assertion command runs from the directory containing the config. Use a leaf `tsconfig.json` and an explicitly authorized argument array, not a shell command string. Compilation must pass before the command runs. The project compiler and test command are trusted local code with your permissions. Time and output limits are not a sandbox.

Add `queryId` from a prior search to associate validation with that query. Omitting `testCommand` requests compilation only. Unsaved overlays can be checked but cannot receive runtime test evidence. Save the actual code before requesting execution.

### Read the evidence

| Result | What it establishes |
| :--- | :--- |
| Retrieved API | A candidate was found in the indexed package |
| Resolved API | The installed compiler found a workspace declaration |
| `checks.typechecked` | The compiler's result for the recorded project inputs |
| `checks.tested` | The result of the explicitly supplied assertion command |
| `checks.stable` | Whether the recorded input scope stayed unchanged across validation |

Results keep `pass`, `fail`, `unknown`, and `not-run` distinct. A command returning zero establishes only the assertions it actually ran. `artifactMatch` remains `unknown` when installed contents have not been compared with the registry artifact.

Validation's overall `success` is true only when compilation, assertion execution, and input stability all pass. A compilation only request can therefore have `checks.typechecked.status` equal to `pass`, `checks.tested.status` equal to `not-run`, and `success` equal to `false`. Read the individual checks rather than interpreting that as a compiler failure. The CLI uses status 2 when required checks fail and status 1 for command errors.

`workspace_validate` defaults to `detail: "compact"`. Checks, diagnostics, test output and snapshot IDs are preserved. The `snapshot` and `runtimeSnapshot` summaries report `inputCount` and `inputsOmitted` instead of listing individual input rows. Add `"detail": "full"` to an MCP request to include every row.

CLI output and saved validation evidence retain full input manifests. `record: false` or `TYPELATCH_USAGE=off` disables saving and leaves `evidencePath` null. Selecting full detail does not enable recording.

Validation records compiler inputs and, when execution is requested, the runtime file scope before and after the command. `runtimeInputs` extends that scope. `snapshotExclude` excludes known generated outputs. `workspaceRoot` bounds snapshot collection. Excluded files, remote services, and environmental state are outside the recorded evidence boundary.

## MCP tool reference

| Tool | Request | Result |
| :--- | :--- | :--- |
| `workspace_search` | absolute `workspaceRoot`, `question`; optional `scope`, `file`, `detail`, `limit` from 1 to 20, `timeoutMs` | Ranked local file and exact dependency candidates, cache refresh details, coverage and evidence limits |
| `library_search` | `package`, `question`; optional `version`, `limit` from 1 to 20 | Search results from an installed index |
| `library_symbol` | `package`, `symbol`; optional `version` | Exact symbol lookup and relationships |
| `workspace_context` | `config`, `file`; optional `importSpecifier`, `symbol`, `position`, `question`, `expectedVersion`, `overlays`, `limit`, `timeoutMs` | Workspace definitions, types, identity, and optional discovery |
| `workspace_validate` | `config`; optional `detail` (`compact` or `full`), `testCommand`, `queryId`, `record`, `overlays`, `timeoutMs`, `runtimeInputs`, `snapshotExclude`, `workspaceRoot` | Compiler, execution, and input stability evidence with compact input summaries by default |
| `library_feedback` | `queryId` UUID; optional `accepted`, `compilePassed`, `testsPassed`, `notes` up to 1000 characters | Agent reported outcome stored against a prior query |
| `library_stats` | `{}` | Local query, latency, hit rate, context size, and outcome aggregates |

Workspace tools accept the same execution fields as the corresponding CLI request files. Validation `detail` selects the MCP response view; CLI validation output remains full. Feedback is an agent report, not a compiler or test run. It remains separate from tool executed validation records. Index preparation uses the CLI. There is no MCP install tool or arbitrary SQL query tool.

## Local data and source setup

Indexes and query history live in `~/.typelatch`. `TYPELATCH_HOME` selects another directory. `TYPELATCH_USAGE=off` disables query and validation recording. Explicit feedback can still update an existing query when requested. Query history can contain source related questions and feedback notes. The application does not upload that history. [Security](../SECURITY.md) describes the trust boundary.

To build and verify Typelatch itself:

```sh
git clone https://github.com/eDimka/typelatch.git
cd typelatch
npm ci
npm run release:check
npm link
```

[Contributing](../CONTRIBUTING.md) · [Architecture](ARCHITECTURE.md) · [Benchmark evidence](BENCHMARKS.md) · [Release checks](RELEASE.md)
